### fbc
```sh
Facebook Cracking
Source By : https://github.com/sptty-chan/
Kang Recode : https://github.com/JaeXploit
```
### bahan
```sh
> pkg upgrade && pkg update
> pkg install python
> pkg install git
> pip install requests
> pip install bs4
> pip install rich
> pip install futures
> pip install mechanize
> git clone https://github.com/JaeXploit/fbc
```
### cara running
```sh 
> cd fbc
> python fbc.py
> python2 fbc.py
```
### access log-in
```sh 
TOKEN
```